# app/pages/page_farmacia.py
"""
Page: Farmacia (Dispensación)

UI:
- Paciente ID -> cargar recetas
- Tabla recetas -> seleccionar receta
- Tabla líneas -> seleccionar línea
- Botón dispensar
"""

from __future__ import annotations

from typing import List, Optional

from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.pages.base_page import BasePage
from app.controllers.farmacia_controller import FarmaciaController
from container import AppContainer


class PageFarmacia(BasePage):
    page_id = "farmacia"
    title = "Farmacia"

    def __init__(self, container: AppContainer, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self._c = container
        self._controller = FarmaciaController(self, container)

        # Top: paciente
        self.ed_paciente = QLineEdit()
        self.ed_paciente.setPlaceholderText("Paciente ID…")

        self.btn_cargar = QPushButton("Cargar recetas")

        top = QHBoxLayout()
        top.addWidget(QLabel("Paciente ID:"))
        top.addWidget(self.ed_paciente)
        top.addWidget(self.btn_cargar)
        top.addStretch(1)

        # Tabla recetas
        self.tbl_recetas = QTableWidget(0, 4)
        self.tbl_recetas.setHorizontalHeaderLabels(["ID", "Fecha", "Médico", "Observaciones"])
        self.tbl_recetas.horizontalHeader().setStretchLastSection(True)

        # Tabla líneas
        self.tbl_lineas = QTableWidget(0, 6)
        self.tbl_lineas.setHorizontalHeaderLabels(["Línea ID", "Medicamento", "Stock", "Dosis", "Duración", "Instrucciones"])
        self.tbl_lineas.horizontalHeader().setStretchLastSection(True)

        # Info + acciones
        self.lbl_sel = QLabel("Selección: —")
        self.btn_dispensar = QPushButton("Dispensar línea seleccionada")

        actions = QHBoxLayout()
        actions.addWidget(self.lbl_sel)
        actions.addStretch(1)
        actions.addWidget(self.btn_dispensar)

        layout = QVBoxLayout()
        layout.addLayout(top)
        layout.addSpacing(10)
        layout.addWidget(QLabel("Recetas:"))
        layout.addWidget(self.tbl_recetas)
        layout.addSpacing(10)
        layout.addWidget(QLabel("Líneas de receta:"))
        layout.addWidget(self.tbl_lineas)
        layout.addLayout(actions)

        self.setLayout(layout)

        # Signals
        self.btn_cargar.clicked.connect(self._on_cargar)
        self.tbl_recetas.currentCellChanged.connect(self._on_receta_selected)
        self.tbl_lineas.currentCellChanged.connect(self._on_linea_selected)
        self.btn_dispensar.clicked.connect(self._on_dispensar)

        self._current_receta_id: Optional[int] = None
        self._current_linea_id: Optional[int] = None
        self._current_medicamento_id: Optional[int] = None

    def on_show(self) -> None:
        # no auto recarga
        return

    # ------------------------------------------------------------
    # Handlers
    # ------------------------------------------------------------

    def _on_cargar(self) -> None:
        try:
            paciente_id = int((self.ed_paciente.text() or "").strip())
        except ValueError:
            QMessageBox.warning(self, "Farmacia", "Paciente ID inválido.")
            return

        try:
            recetas = self._controller.list_recetas_by_paciente(paciente_id)
        except Exception as e:
            QMessageBox.critical(self, "Farmacia - Error", str(e))
            return

        self._render_recetas(recetas)
        self._render_lineas([])
        self._current_receta_id = None
        self._current_linea_id = None
        self._current_medicamento_id = None
        self._update_selection_label()

    def _on_receta_selected(self, row: int, col: int, prev_row: int, prev_col: int) -> None:
        receta_id = self._get_int_cell(self.tbl_recetas, row, 0)
        if not receta_id:
            return
        self._current_receta_id = receta_id

        try:
            lineas = self._controller.list_lineas_by_receta(receta_id)
        except Exception as e:
            QMessageBox.critical(self, "Farmacia - Error", str(e))
            return

        self._render_lineas(lineas)
        self._current_linea_id = None
        self._current_medicamento_id = None
        self._update_selection_label()

    def _on_linea_selected(self, row: int, col: int, prev_row: int, prev_col: int) -> None:
        linea_id = self._get_int_cell(self.tbl_lineas, row, 0)
        if not linea_id:
            return
        self._current_linea_id = linea_id

        # medicamento_id lo guardamos como dato oculto en Qt.UserRole
        mid_item = self.tbl_lineas.item(row, 1)
        if mid_item:
            mid = mid_item.data(32)  # Qt.UserRole = 32
            self._current_medicamento_id = int(mid) if mid else None

        self._update_selection_label()

    def _on_dispensar(self) -> None:
        if not (self._current_receta_id and self._current_linea_id and self._current_medicamento_id):
            QMessageBox.warning(self, "Farmacia", "Selecciona una receta y una línea antes de dispensar.")
            return

        ok = self._controller.dispensar_flow(
            receta_id=self._current_receta_id,
            receta_linea_id=self._current_linea_id,
            medicamento_id=self._current_medicamento_id,
        )
        if ok:
            # refrescar líneas para ver stock actualizado
            try:
                lineas = self._controller.list_lineas_by_receta(self._current_receta_id)
                self._render_lineas(lineas)
            except Exception:
                pass

    # ------------------------------------------------------------
    # Render
    # ------------------------------------------------------------

    def _render_recetas(self, recetas: List[dict]) -> None:
        self.tbl_recetas.setRowCount(0)
        for r in recetas:
            row = self.tbl_recetas.rowCount()
            self.tbl_recetas.insertRow(row)
            self.tbl_recetas.setItem(row, 0, QTableWidgetItem(str(r["id"])))
            self.tbl_recetas.setItem(row, 1, QTableWidgetItem(str(r["fecha"])))
            self.tbl_recetas.setItem(row, 2, QTableWidgetItem(str(r["medico_id"])))
            self.tbl_recetas.setItem(row, 3, QTableWidgetItem(r["observaciones"]))
        self.tbl_recetas.resizeColumnsToContents()

    def _render_lineas(self, lineas: List[dict]) -> None:
        self.tbl_lineas.setRowCount(0)
        for l in lineas:
            row = self.tbl_lineas.rowCount()
            self.tbl_lineas.insertRow(row)

            self.tbl_lineas.setItem(row, 0, QTableWidgetItem(str(l["id"])))

            med_item = QTableWidgetItem(l["nombre"])
            med_item.setData(32, int(l["medicamento_id"]))  # Qt.UserRole
            self.tbl_lineas.setItem(row, 1, med_item)

            self.tbl_lineas.setItem(row, 2, QTableWidgetItem(str(l["stock"])))
            self.tbl_lineas.setItem(row, 3, QTableWidgetItem(str(l["dosis"])))
            self.tbl_lineas.setItem(row, 4, QTableWidgetItem(str(l["duracion_dias"])))
            self.tbl_lineas.setItem(row, 5, QTableWidgetItem(str(l["instrucciones"])))

        self.tbl_lineas.resizeColumnsToContents()

    def _update_selection_label(self) -> None:
        self.lbl_sel.setText(
            f"Selección: receta={self._current_receta_id or '—'} | "
            f"línea={self._current_linea_id or '—'} | "
            f"med={self._current_medicamento_id or '—'}"
        )

    # ------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------

    def _get_int_cell(self, table: QTableWidget, row: int, col: int) -> Optional[int]:
        if row < 0:
            return None
        item = table.item(row, col)
        if not item:
            return None
        try:
            return int(item.text())
        except ValueError:
            return None
