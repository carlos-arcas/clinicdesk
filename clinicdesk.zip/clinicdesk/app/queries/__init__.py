"""Queries (lecturas) para la UI.

Regla:
- SELECTs complejos (joins, filtros, proyecciones) viven aquí.
- Los casos de uso (usecases) son para escrituras con reglas.
"""
