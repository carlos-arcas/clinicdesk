from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from clinicdesk.app.container import AppContainer


@dataclass(frozen=True, slots=True)
class RecetaRow:
    id: int
    fecha: str
    medico_id: int
    medico_nombre: str
    observaciones: Optional[str]


@dataclass(frozen=True, slots=True)
class RecetaLineaRow:
    id: int
    receta_id: int
    medicamento_id: int
    medicamento_nombre: str
    dosis: str
    duracion_dias: Optional[int]
    instrucciones: Optional[str]
    medicamento_stock: int
    medicamento_activo: bool


class FarmaciaQueries:
    def __init__(self, container: AppContainer) -> None:
        self._c = container

    def list_recetas_by_paciente(self, paciente_id: int) -> List[RecetaRow]:
        rows = self._c.connection.execute(
            """
            SELECT
                r.id,
                r.fecha,
                r.medico_id,
                (m.nombre || ' ' || m.apellidos) AS medico_nombre,
                r.observaciones
            FROM recetas r
            JOIN medicos m ON m.id = r.medico_id
            WHERE r.paciente_id = ?
            ORDER BY r.fecha DESC, r.id DESC
            """,
            (paciente_id,),
        ).fetchall()

        out: List[RecetaRow] = []
        for x in rows:
            out.append(
                RecetaRow(
                    id=int(x["id"]),
                    fecha=x["fecha"],
                    medico_id=int(x["medico_id"]),
                    medico_nombre=x["medico_nombre"],
                    observaciones=x["observaciones"],
                )
            )
        return out

    def list_lineas_by_receta(self, receta_id: int) -> List[RecetaLineaRow]:
        rows = self._c.connection.execute(
            """
            SELECT
                rl.id,
                rl.receta_id,
                rl.medicamento_id,
                (med.nombre_comercial || ' (' || med.nombre_compuesto || ')') AS medicamento_nombre,
                rl.dosis,
                rl.duracion_dias,
                rl.instrucciones,
                med.stock AS medicamento_stock,
                med.activo AS medicamento_activo
            FROM receta_lineas rl
            JOIN medicamentos med ON med.id = rl.medicamento_id
            WHERE rl.receta_id = ?
            ORDER BY rl.id
            """,
            (receta_id,),
        ).fetchall()

        out: List[RecetaLineaRow] = []
        for x in rows:
            out.append(
                RecetaLineaRow(
                    id=int(x["id"]),
                    receta_id=int(x["receta_id"]),
                    medicamento_id=int(x["medicamento_id"]),
                    medicamento_nombre=x["medicamento_nombre"],
                    dosis=x["dosis"],
                    duracion_dias=x["duracion_dias"],
                    instrucciones=x["instrucciones"],
                    medicamento_stock=int(x["medicamento_stock"]),
                    medicamento_activo=bool(x["medicamento_activo"]),
                )
            )
        return out
