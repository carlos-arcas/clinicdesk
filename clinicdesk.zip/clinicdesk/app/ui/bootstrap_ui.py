from __future__ import annotations

from clinicdesk.app.container import AppContainer
from clinicdesk.app.ui.pages.pages_registry import PageRegistry

# Registro por feature (una import por feature).
from clinicdesk.app.ui.pages.home.register import register as register_home
from clinicdesk.app.ui.pages.citas.register import register as register_citas
from clinicdesk.app.ui.pages.farmacia.register import register as register_farmacia
from clinicdesk.app.ui.pages.incidencias.register import register as register_incidencias


def register_pages(registry: PageRegistry, container: AppContainer) -> None:
    """Punto único de registro de páginas.

    Regla:
    - Este archivo solo orquesta imports/llamadas a register().
    - No contiene UI ni lógica de negocio.
    """
    register_home(registry, container)
    register_citas(registry, container)
    register_farmacia(registry, container)
    register_incidencias(registry, container)
